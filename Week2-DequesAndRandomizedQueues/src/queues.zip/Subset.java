import edu.princeton.cs.algs4.StdIn;


public class Subset {
    private final RandomizedQueue<String> rq;
    
    public Subset() {
        rq = new RandomizedQueue<String>();
    }
    
    private void print(int numberToPrint) {
        int x = numberToPrint;
        while (x-- > 0) {
            System.out.println(rq.dequeue());
        }
    }
    
    public static void main(String[] args) {
        int numberToPrint = Integer.parseInt(args[0]);
        //String input = StdIn.readAll();
         
        final Subset ss = new Subset();
        int y = numberToPrint;
        while (y-- > 0) { 
            String item = StdIn.readString();
            ss.rq.enqueue(item);
        }
        
        ss.print(numberToPrint);
    }
}
